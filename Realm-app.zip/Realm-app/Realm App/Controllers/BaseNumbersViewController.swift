//
//  ViewController.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import UIKit
import RealmSwift

class BaseNumbersViewController: UITableViewController {

    let realm = try! Realm()
    
    let baNumbers = [0,1,2,3,4,5,6,7,8,9]
    
    var numbers : Results<BaseNumbers>?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadNumbers()
        
        if (realm.objects(BaseNumbers.self).count != baNumbers.count) {
            initWriteToRealm(readyNumbers: baNumbers)
        }
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BaseNumbers", for: indexPath)
        cell.textLabel?.text = "\(numbers?[indexPath.row].baseNumber ?? 0)"
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "middleNumbers", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "middleNumbers" {
            let destinationVC = segue.destination as! MiddleNumbersTableViewController
        
            if let indexPath = tableView.indexPathForSelectedRow{
                destinationVC.selectedNumber = numbers?[indexPath.row]
            }
        }
    }


    func initWriteToRealm (readyNumbers: [Int]) {
        
        for i in readyNumbers {
            
            let bNumber = BaseNumbers()
            bNumber.baseNumber = i * 10
            do {
                try realm.write{
                    realm.add(bNumber)
                }
            } catch{
                print("error loading base number")
            }
        }
        numbers = realm.objects(BaseNumbers.self)
    }
    
    func loadNumbers (){
        numbers = realm.objects(BaseNumbers.self)
        tableView.reloadData()
    }
    
    
}

