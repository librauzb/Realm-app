//
//  FinalNumbersTableViewController.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import UIKit
import RealmSwift
import SwipeCellKit

class FinalNumbersTableViewController: UITableViewController {

    let realm = try! Realm()
    
    var numbers : Results<FinalNumbers>?
    
    var selectedNumber: MiddleNumbers? {
        didSet {
            loadNumbers()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadNumbers()
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FinalNumbers", for: indexPath) as! SwipeTableViewCell
        cell.textLabel?.text = "\(numbers?[indexPath.row].finalNumber ?? 0)"
        cell.delegate = self
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    @IBAction func plusBtnPressed(_ sender: UIBarButtonItem) {
        
        var textField = UITextField()
        let alert = UIAlertController(title: "New number", message: "Add a new number", preferredStyle: .alert)
        let action = UIAlertAction(title: "Save", style: .default) { (action) in
            if let currentCategory = self.selectedNumber {
                do {
                    try self.realm.write {
                        let newItem = FinalNumbers()
                        
                        if let createdNumber = NumberFormatter().number(from: textField.text!){
                            let myIntNumber = createdNumber.intValue
                                newItem.finalNumber = myIntNumber
                                newItem.dataCreated = Date()
                                currentCategory.fNumbers.append(newItem)
                            }
                        else{
                            
                            let errorAlert = UIAlertController(title: "Error", message: "Please add integer to the list", preferredStyle: UIAlertController.Style.alert)

                            errorAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                            }))

                            self.present(errorAlert, animated: true, completion: nil)
                        }
                    }
                } catch {
                    print("Error saving new items, \(error)")
                }
            }
            self.tableView.reloadData()
        }
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "Create a new number"
            textField = alertTextField
        }
        
         alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
         }))

        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func loadNumbers (){
        numbers = selectedNumber?.fNumbers.sorted(byKeyPath: "dataCreated", ascending: true)
        tableView.reloadData()
    }
    
}

extension FinalNumbersTableViewController : SwipeTableViewCellDelegate {
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath, for orientation: SwipeActionsOrientation) -> [SwipeAction]? {
        guard orientation == .right else {return nil}
        
        let deleteAction = SwipeAction(style: .destructive, title: "Delete") { (action, indexPath) in
            
            if let numberForDeletion = self.numbers?[indexPath.row]{
                
                do {
                    try self.realm.write{
                        self.realm.delete(numberForDeletion)
                    }
                } catch  {
                    print("error deleting a number")
                }
                
                tableView.reloadData()
            }
            
        }
        
        return [deleteAction]
    }
    
    
}
