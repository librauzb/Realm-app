//
//  MiddleNumbersTableViewController.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import UIKit
import RealmSwift

class MiddleNumbersTableViewController: UITableViewController {
    
    let realm = try! Realm()
    
    let MidNumbers = [0,1,2,3,4,5,6,7,8,9]
    
    var numbers : Results<MiddleNumbers>?

    var selectedNumber: BaseNumbers? {
        didSet {
            loadNumbers()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadNumbers()
        
        initWriteToRealm(readyNumbers: MidNumbers)
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MiddleNumbers", for: indexPath)
        cell.textLabel?.text = "\(numbers?[indexPath.row].middleNumber ?? 0)"
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "finalNumbers", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "finalNumbers" {
            let destinationVC = segue.destination as! FinalNumbersTableViewController
        
            if let indexPath = tableView.indexPathForSelectedRow{
                destinationVC.selectedNumber = numbers?[indexPath.row]
            }
        }
    }


    func initWriteToRealm (readyNumbers: [Int]) {
        
        if let currentNumber = self.selectedNumber {

            if (currentNumber.numbers.count != MidNumbers.count){
            
                for i in readyNumbers {
            
                    do {
                        try realm.write{
                            let mNumber = MiddleNumbers()
                            mNumber.middleNumber = currentNumber.baseNumber + i + 1
                            currentNumber.numbers.append(mNumber)
                            realm.add(mNumber)
                        }
                    } catch{
                        print("error loading middle number")
                    }
                }
                
                numbers = realm.objects(MiddleNumbers.self)
                loadNumbers()
            }
        }
    }
    
    func loadNumbers (){
        numbers = selectedNumber?.numbers.sorted(byKeyPath: "middleNumber", ascending: true)
        tableView.reloadData()
    }
    
}
