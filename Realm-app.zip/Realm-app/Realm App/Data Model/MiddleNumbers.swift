//
//  MiddleNumbers.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import Foundation
import RealmSwift

class MiddleNumbers: Object {
    @objc dynamic var middleNumber: Int = 0
    let fNumbers = List<FinalNumbers>()
    var parentNumber = LinkingObjects(fromType: BaseNumbers.self, property: "numbers")
}
