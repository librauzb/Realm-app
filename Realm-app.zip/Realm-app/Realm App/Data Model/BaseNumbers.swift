//
//  BaseNumbers.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import Foundation
import RealmSwift

class BaseNumbers: Object {
    @objc dynamic var  baseNumber: Int = 0
    let numbers = List<MiddleNumbers>()
}
