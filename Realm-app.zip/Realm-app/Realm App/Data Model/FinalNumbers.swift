//
//  FinalNumbers.swift
//  Realm App
//
//  Created by O’lmasbek Axtamov on 12/3/20.
//  Copyright © 2020 O’lmasbek Axtamov. All rights reserved.
//

import Foundation
import RealmSwift

class FinalNumbers: Object {
    @objc dynamic var finalNumber: Int = 0
    @objc dynamic var dataCreated: Date = Date()
    var pNumber = LinkingObjects(fromType: MiddleNumbers.self, property: "fNumbers")}
